let noteCount = localStorage.getItem('noteCount') ? parseInt(localStorage.getItem('noteCount')) : 0; // Лічильник для унікальних ID нотаток

function create() {
    noteCount++; // Збільшуємо лічильник для нового ID
    localStorage.setItem('noteCount', noteCount); // Зберігаємо лічильник у localStorage
    const noteId = `note${noteCount}`; // Генеруємо унікальний ID для нотатки

    const note = document.createElement('div');
    note.className = 'draggable';
    note.setAttribute('data-id', noteId); // Додаємо атрибут data-id для нотатки
    
    // Встановлюємо початкову позицію
    note.style.left = '100px'; 
    note.style.top = '100px'; 

    // Створюємо кнопку закриття
    const closeButton = document.createElement('div');
    closeButton.className = 'close-button';
    closeButton.innerHTML = '&times;'; // Хрестик (символ)
    note.appendChild(closeButton); // Додаємо кнопку закриття до нотатки

    // Створюємо textarea елемент
    const textarea = document.createElement('textarea'); 
    textarea.placeholder = 'Введіть текст...'; 
    note.appendChild(textarea); // Додаємо textarea до нотатки

    document.body.appendChild(note);

    // Додаємо функціонал перетягування
    addDragAndDrop(note);

    // Додаємо обробник подій для кнопки закриття
    closeButton.addEventListener('click', () => {
        removeNoteData(noteId); // Видаляємо дані з localStorage
        document.body.removeChild(note); // Видаляємо нотатку при натисканні на кнопку закриття
    });

    // Зберігаємо дані кожну секунду
    setInterval(() => {
        const noteData = {
            id: noteId,
            content: textarea.value,
            position: {
                left: note.style.left,
                top: note.style.top
            }
        };
        saveNoteData(noteData);
    }, 1000);
}

// Функція для збереження даних у localStorage
function saveNoteData(noteData) {
    let notes = JSON.parse(localStorage.getItem('notes')) || [];
    
    // Знайти індекс нотатки за ID
    const existingNoteIndex = notes.findIndex(note => note.id === noteData.id);
    
    if (existingNoteIndex > -1) {
        notes[existingNoteIndex] = noteData; // Оновлюємо існуючу нотатку
    } else {
        notes.push(noteData); // Додаємо нову нотатку
    }
    
    localStorage.setItem('notes', JSON.stringify(notes));
}

// Функція для видалення нотатки з localStorage
function removeNoteData(noteId) {
    let notes = JSON.parse(localStorage.getItem('notes')) || [];
    notes = notes.filter(note => note.id !== noteId); // Фільтруємо нотатки, видаляючи ту, що має даний ID
    localStorage.setItem('notes', JSON.stringify(notes));
}

// Функція для відновлення нотаток при завантаженні
function loadNotes() {
    const notes = JSON.parse(localStorage.getItem('notes')) || [];
    notes.forEach(noteData => {
        const note = createNoteElement(noteData);
        document.body.appendChild(note);
    });
}

// Функція для створення елемента нотатки
function createNoteElement(noteData) {
    const note = document.createElement('div');
    note.className = 'draggable';
    note.setAttribute('data-id', noteData.id); // Додаємо атрибут data-id для нотатки
    note.style.left = noteData.position.left;
    note.style.top = noteData.position.top;

    const closeButton = document.createElement('div');
    closeButton.className = 'close-button';
    closeButton.innerHTML = '&times;';
    note.appendChild(closeButton);

    const textarea = document.createElement('textarea');
    textarea.value = noteData.content;
    note.appendChild(textarea);

    // Додаємо обробник подій для кнопки закриття
    closeButton.addEventListener('click', () => {
        removeNoteData(noteData.id); // Видаляємо дані з localStorage
        document.body.removeChild(note);
    });

    // Додаємо функціонал перетягування
    addDragAndDrop(note);

    return note;
}

// Функція для додавання функціоналу перетягування
function addDragAndDrop(note) {
    let offsetX, offsetY, isDragging = false;

    function startDrag(e) {
        isDragging = true;
        offsetX = e.clientX - note.getBoundingClientRect().left;
        offsetY = e.clientY - note.getBoundingClientRect().top;
        note.style.cursor = 'grabbing';
        note.style.zIndex = 999; // Піднімаємо нотатку на передній план
        // Знижуємо z-index для всіх інших нотаток
        document.querySelectorAll('.draggable').forEach(otherNote => {
            if (otherNote !== note) {
                otherNote.style.zIndex = 99;
            }
        });
    }

    function drag(e) {
        if (isDragging) {
            note.style.left = (e.clientX - offsetX) + 'px';
            note.style.top = (e.clientY - offsetY) + 'px';
        }
    }

    function endDrag() {
        isDragging = false;
        note.style.cursor = 'grab';
    }

    note.addEventListener('mousedown', startDrag);
    document.addEventListener('mousemove', drag);
    document.addEventListener('mouseup', endDrag);

    // Додатково для мобільних пристроїв
    note.addEventListener('touchstart', (e) => {
        startDrag(e.touches[0]);
    });
    document.addEventListener('touchmove', (e) => {
        drag(e.touches[0]);
    });
    document.addEventListener('touchend', endDrag);
}

// Викликаємо функцію для завантаження нотаток при завантаженні сторінки
window.onload = loadNotes;